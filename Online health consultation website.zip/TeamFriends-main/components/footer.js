function footer() {
    return `    <div id="footer_container">
    <div class="box1">  
        <div id="box2">      
            <div id="box3"> 
                <div>
            <img id="image" style="width:30%" src="https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1606295435/staging/Home/Images/bodywise-logo.png" alt="bebodywise">
        </div>
        <ul id="prod" id="ul">
            <li id="list">
                <a href="/All products/index.html">Hair</a>
            </li>

            <li id="list">
                <a href="/All products/index.html">Skin</a>
            </li>

            <li id="list">
                <a href="/All products/index.html">Nutrition</a>
            </li>
        </ul>

        <ul id="prod1" id="ul">
            <li id="list">
                <a href="/All products/index.html">PCOS</a>
            </li>

            <li id="list">
                <a href="/All products/index.html">Intimate Care</a>
            </li>

            <li id="list">
                <a href="/All products/index.html">Blog</a>
            </li>
        </ul>
</div>

<!-- 2nd part -->
<div id="about">
    <ul id="ul">
        <li id="list"><a href="/Home/index.html">Contact Us</a></li>
        <li id="list"><a href="/Home/index.html">About Us</a></li>
    </ul>

    <ul id="ul">
        <li id="list"><a href="">FAQs</a></li>
        <li id="list"><a href="">Returns&Refunds</a></li>
    </ul>
</div>

<!-- 3rd part -->
<div id="add">
    <div id="add1">
        <ul id="r1" class="ul">
                <li id="list"><a href=""><img id="image" src="https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_50,c_limit/v1603435299/staging/Home/Images/insta.png" alt=""/> </a></li>
                <li id="list"><a href=""><img id="image" src="https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_50,c_limit/v1603435299/staging/Home/Images/fb.png" alt=""/> </a></li>
                <li id="list"><a href=""><img id="image" src="https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_50,c_limit/v1603435299/staging/Home/Images/youtube.png" alt=""/> </a></li>
            </ul>

            <ul id="r1" class="ul">
                <li id="list"><a href="">Privacy Policy</a></li>
                <li id="list"><a href="">Sitemap</a></li>
                <li id="list"><a href="">Join Community</a></li>
            </ul>

            <p>Copyright © 2022 BeBodywise. All rights reserved</p>
    </div>
</div>

</div>
</div>
</div>`
}
export default footer
