       
    //    --------NAVBAR --------

       function navbar()
        {
            return ` <div id="nav">
            <div id="header_logo" >
            <a href="/Home/index.html"> <img id="logoImage" src="https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1606295435/staging/Home/Images/bodywise-logo.png" alt="beBodywise"></a>
            </div>
            <!---->

            <div id="header_menu">
                            <div><a href="/BookdoctorConsultation/new.html">Book Doctor Consultation</a></div>
                            <div><a href="/Take Wellness/index.html">Take Wellness Assessment</a></div>
                            <div><a href="/Choose Concern/index.html">Choose Concern</a></div>
                            <div><a href="/All products/index.html">All Products</a></div>
                            <div><a href="/Refer Earn/index.html">Refer & Earn</a></div>
                        </div>

            <!---->
            <div id="header_controls" >
            
                            <div id="icons"><a href="/Login Cart/search.html"><img src="https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_48/v1603950724/staging/Home/Images/u_search.svg" alt=""></a></div>
                            <div id="icons"><a href="/Login Cart/login.html"><img src="https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_48/v1603950724/staging/Home/Images/u_user.svg" alt=""></a></div>
                            <div id="icons"><a href="https://api.whatsapp.com/send/?phone=917710096671&text=Hey%21+I+would+like+to+know+more+about+Bodywise.&app_absent=0"><img src="https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_48/v1603950724/staging/Home/Images/WhastApp.svg" alt=""></a></div>
                            <div id="icons"><a href="/Login Cart/cart.html"><img src="https://res.cloudinary.com/mosaic-wellness/image/upload/v1603950724/staging/Home/Images/u_shopping-bag.svg" alt="" width="24px" height="24px"></a></div>
                        </div>
        </div>`
        }

        export default navbar