var skinArr = [
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1613991979/staging/products/hair-health-gummies/Carousel%20NEW/Hair_white-BG.jpg",
        title:"Biotin Hair Gummies (30)",
        price:599,
        for:"FOR Hair growth & strength",
        with:"WITH Biotin 5000 MCG, Multivitamins, Zinc"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1613991979/staging/products/hair-health-gummies/Carousel%20NEW/Hair_white-BG.jpg",
        title:"Biotin Hair Gummies (30)",
        price:599,
        for:"FOR Hair growth & strength",
        with:"WITH Biotin 5000 MCG, Multivitamins, Zinc"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1613991979/staging/products/hair-health-gummies/Carousel%20NEW/Hair_white-BG.jpg",
        title:"Biotin Hair Gummies (30)",
        price:599,
        for:"FOR Hair growth & strength",
        with:"WITH Biotin 5000 MCG, Multivitamins, Zinc"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1613991979/staging/products/hair-health-gummies/Carousel%20NEW/Hair_white-BG.jpg",
        title:"Biotin Hair Gummies (30)",
        price:599,
        for:"FOR Hair growth & strength",
        with:"WITH Biotin 5000 MCG, Multivitamins, Zinc"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1613991979/staging/products/hair-health-gummies/Carousel%20NEW/Hair_white-BG.jpg",
        title:"Biotin Hair Gummies (30)",
        price:599,
        for:"FOR Hair growth & strength",
        with:"WITH Biotin 5000 MCG, Multivitamins, Zinc"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1613991979/staging/products/hair-health-gummies/Carousel%20NEW/Hair_white-BG.jpg",
        title:"Biotin Hair Gummies (30)",
        price:599,
        for:"FOR Hair growth & strength",
        with:"WITH Biotin 5000 MCG, Multivitamins, Zinc"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1613991979/staging/products/hair-health-gummies/Carousel%20NEW/Hair_white-BG.jpg",
        title:"Biotin Hair Gummies (30)",
        price:599,
        for:"FOR Hair growth & strength",
        with:"WITH Biotin 5000 MCG, Multivitamins, Zinc"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1613991979/staging/products/hair-health-gummies/Carousel%20NEW/Hair_white-BG.jpg",
        title:"Biotin Hair Gummies (30)",
        price:599,
        for:"FOR Hair growth & strength",
        with:"WITH Biotin 5000 MCG, Multivitamins, Zinc"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1613991979/staging/products/hair-health-gummies/Carousel%20NEW/Hair_white-BG.jpg",
        title:"Biotin Hair Gummies (30)",
        price:599,
        for:"FOR Hair growth & strength",
        with:"WITH Biotin 5000 MCG, Multivitamins, Zinc"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1613991979/staging/products/hair-health-gummies/Carousel%20NEW/Hair_white-BG.jpg",
        title:"Biotin Hair Gummies (30)",
        price:599,
        for:"FOR Hair growth & strength",
        with:"WITH Biotin 5000 MCG, Multivitamins, Zinc"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1613991979/staging/products/hair-health-gummies/Carousel%20NEW/Hair_white-BG.jpg",
        title:"Biotin Hair Gummies (30)",
        price:599,
        for:"FOR Hair growth & strength",
        with:"WITH Biotin 5000 MCG, Multivitamins, Zinc"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1613991979/staging/products/hair-health-gummies/Carousel%20NEW/Hair_white-BG.jpg",
        title:"Biotin Hair Gummies (30)",
        price:599,
        for:"FOR Hair growth & strength",
        with:"WITH Biotin 5000 MCG, Multivitamins, Zinc"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1613991979/staging/products/hair-health-gummies/Carousel%20NEW/Hair_white-BG.jpg",
        title:"Biotin Hair Gummies (30)",
        price:599,
        for:"FOR Hair growth & strength",
        with:"WITH Biotin 5000 MCG, Multivitamins, Zinc"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1613991979/staging/products/hair-health-gummies/Carousel%20NEW/Hair_white-BG.jpg",
        title:"Biotin Hair Gummies (30)",
        price:599,
        for:"FOR Hair growth & strength",
        with:"WITH Biotin 5000 MCG, Multivitamins, Zinc"
    },
]

var hairArr = [
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1636804535/staging/products/skin-clarifying/0_BLUE/PRODUCT%20IMAGES/10NS_1000x750.jpg",
        title:"10% Niacinamide Serum ",
        price:400,
        for:"FOR Acne Marks, Hyperpigmentation",
        with:"WITH 10% Niacinamide, 1% Zinc PCA"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1636804535/staging/products/skin-clarifying/0_BLUE/PRODUCT%20IMAGES/10NS_1000x750.jpg",
        title:"10% Niacinamide Serum ",
        price:400,
        for:"FOR Acne Marks, Hyperpigmentation",
        with:"WITH 10% Niacinamide, 1% Zinc PCA"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1636804535/staging/products/skin-clarifying/0_BLUE/PRODUCT%20IMAGES/10NS_1000x750.jpg",
        title:"10% Niacinamide Serum ",
        price:400,
        for:"FOR Acne Marks, Hyperpigmentation",
        with:"WITH 10% Niacinamide, 1% Zinc PCA"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1636804535/staging/products/skin-clarifying/0_BLUE/PRODUCT%20IMAGES/10NS_1000x750.jpg",
        title:"10% Niacinamide Serum ",
        price:400,
        for:"FOR Acne Marks, Hyperpigmentation",
        with:"WITH 10% Niacinamide, 1% Zinc PCA"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1636804535/staging/products/skin-clarifying/0_BLUE/PRODUCT%20IMAGES/10NS_1000x750.jpg",
        title:"10% Niacinamide Serum ",
        price:400,
        for:"FOR Acne Marks, Hyperpigmentation",
        with:"WITH 10% Niacinamide, 1% Zinc PCA"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1636804535/staging/products/skin-clarifying/0_BLUE/PRODUCT%20IMAGES/10NS_1000x750.jpg",
        title:"10% Niacinamide Serum ",
        price:400,
        for:"FOR Acne Marks, Hyperpigmentation",
        with:"WITH 10% Niacinamide, 1% Zinc PCA"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1636804535/staging/products/skin-clarifying/0_BLUE/PRODUCT%20IMAGES/10NS_1000x750.jpg",
        title:"10% Niacinamide Serum ",
        price:400,
        for:"FOR Acne Marks, Hyperpigmentation",
        with:"WITH 10% Niacinamide, 1% Zinc PCA"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1636804535/staging/products/skin-clarifying/0_BLUE/PRODUCT%20IMAGES/10NS_1000x750.jpg",
        title:"10% Niacinamide Serum ",
        price:400,
        for:"FOR Acne Marks, Hyperpigmentation",
        with:"WITH 10% Niacinamide, 1% Zinc PCA"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1636804535/staging/products/skin-clarifying/0_BLUE/PRODUCT%20IMAGES/10NS_1000x750.jpg",
        title:"10% Niacinamide Serum ",
        price:400,
        for:"FOR Acne Marks, Hyperpigmentation",
        with:"WITH 10% Niacinamide, 1% Zinc PCA"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1636804535/staging/products/skin-clarifying/0_BLUE/PRODUCT%20IMAGES/10NS_1000x750.jpg",
        title:"10% Niacinamide Serum ",
        price:400,
        for:"FOR Acne Marks, Hyperpigmentation",
        with:"WITH 10% Niacinamide, 1% Zinc PCA"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1636804535/staging/products/skin-clarifying/0_BLUE/PRODUCT%20IMAGES/10NS_1000x750.jpg",
        title:"10% Niacinamide Serum ",
        price:400,
        for:"FOR Acne Marks, Hyperpigmentation",
        with:"WITH 10% Niacinamide, 1% Zinc PCA"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1636804535/staging/products/skin-clarifying/0_BLUE/PRODUCT%20IMAGES/10NS_1000x750.jpg",
        title:"10% Niacinamide Serum ",
        price:400,
        for:"FOR Acne Marks, Hyperpigmentation",
        with:"WITH 10% Niacinamide, 1% Zinc PCA"
    },
]

var weightArr = [
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1640076363/staging/products/active-assist-acv-gummies/0_ACV/CAROUSEL/0.jpg",
        title:"Apple Cider Vinegar Gummies (30)",
        price:599,
        for:"FOR Gut health improvement",
        with:"WITH Apple Cider Vinegar, Inulin"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1640076363/staging/products/active-assist-acv-gummies/0_ACV/CAROUSEL/0.jpg",
        title:"Apple Cider Vinegar Gummies (30)",
        price:599,
        for:"FOR Gut health improvement",
        with:"WITH Apple Cider Vinegar, Inulin"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1640076363/staging/products/active-assist-acv-gummies/0_ACV/CAROUSEL/0.jpg",
        title:"Apple Cider Vinegar Gummies (30)",
        price:599,
        for:"FOR Gut health improvement",
        with:"WITH Apple Cider Vinegar, Inulin"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1640076363/staging/products/active-assist-acv-gummies/0_ACV/CAROUSEL/0.jpg",
        title:"Apple Cider Vinegar Gummies (30)",
        price:599,
        for:"FOR Gut health improvement",
        with:"WITH Apple Cider Vinegar, Inulin"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1640076363/staging/products/active-assist-acv-gummies/0_ACV/CAROUSEL/0.jpg",
        title:"Apple Cider Vinegar Gummies (30)",
        price:599,
        for:"FOR Gut health improvement",
        with:"WITH Apple Cider Vinegar, Inulin"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1640076363/staging/products/active-assist-acv-gummies/0_ACV/CAROUSEL/0.jpg",
        title:"Apple Cider Vinegar Gummies (30)",
        price:599,
        for:"FOR Gut health improvement",
        with:"WITH Apple Cider Vinegar, Inulin"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1640076363/staging/products/active-assist-acv-gummies/0_ACV/CAROUSEL/0.jpg",
        title:"Apple Cider Vinegar Gummies (30)",
        price:599,
        for:"FOR Gut health improvement",
        with:"WITH Apple Cider Vinegar, Inulin"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1640076363/staging/products/active-assist-acv-gummies/0_ACV/CAROUSEL/0.jpg",
        title:"Apple Cider Vinegar Gummies (30)",
        price:599,
        for:"FOR Gut health improvement",
        with:"WITH Apple Cider Vinegar, Inulin"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1640076363/staging/products/active-assist-acv-gummies/0_ACV/CAROUSEL/0.jpg",
        title:"Apple Cider Vinegar Gummies (30)",
        price:599,
        for:"FOR Gut health improvement",
        with:"WITH Apple Cider Vinegar, Inulin"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1640076363/staging/products/active-assist-acv-gummies/0_ACV/CAROUSEL/0.jpg",
        title:"Apple Cider Vinegar Gummies (30)",
        price:599,
        for:"FOR Gut health improvement",
        with:"WITH Apple Cider Vinegar, Inulin"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1640076363/staging/products/active-assist-acv-gummies/0_ACV/CAROUSEL/0.jpg",
        title:"Apple Cider Vinegar Gummies (30)",
        price:599,
        for:"FOR Gut health improvement",
        with:"WITH Apple Cider Vinegar, Inulin"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1640076363/staging/products/active-assist-acv-gummies/0_ACV/CAROUSEL/0.jpg",
        title:"Apple Cider Vinegar Gummies (30)",
        price:599,
        for:"FOR Gut health improvement",
        with:"WITH Apple Cider Vinegar, Inulin"
    },
]

var pcosArr = [
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1635160165/staging/products/pms-gummies/PRODUCT%20IMAGES/PMS%20Gummies_1000x750.png",
        title:"PMS Gummies",
        price:999,
        for:"FOR Managing PMS Symptoms",
        with:"WITH Chasteberry Extract, L-tryptophan, St. John's wort"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1635160165/staging/products/pms-gummies/PRODUCT%20IMAGES/PMS%20Gummies_1000x750.png",
        title:"PMS Gummies",
        price:999,
        for:"FOR Managing PMS Symptoms",
        with:"WITH Chasteberry Extract, L-tryptophan, St. John's wort"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1635160165/staging/products/pms-gummies/PRODUCT%20IMAGES/PMS%20Gummies_1000x750.png",
        title:"PMS Gummies",
        price:999,
        for:"FOR Managing PMS Symptoms",
        with:"WITH Chasteberry Extract, L-tryptophan, St. John's wort"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1635160165/staging/products/pms-gummies/PRODUCT%20IMAGES/PMS%20Gummies_1000x750.png",
        title:"PMS Gummies",
        price:999,
        for:"FOR Managing PMS Symptoms",
        with:"WITH Chasteberry Extract, L-tryptophan, St. John's wort"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1635160165/staging/products/pms-gummies/PRODUCT%20IMAGES/PMS%20Gummies_1000x750.png",
        title:"PMS Gummies",
        price:999,
        for:"FOR Managing PMS Symptoms",
        with:"WITH Chasteberry Extract, L-tryptophan, St. John's wort"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1635160165/staging/products/pms-gummies/PRODUCT%20IMAGES/PMS%20Gummies_1000x750.png",
        title:"PMS Gummies",
        price:999,
        for:"FOR Managing PMS Symptoms",
        with:"WITH Chasteberry Extract, L-tryptophan, St. John's wort"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1635160165/staging/products/pms-gummies/PRODUCT%20IMAGES/PMS%20Gummies_1000x750.png",
        title:"PMS Gummies",
        price:999,
        for:"FOR Managing PMS Symptoms",
        with:"WITH Chasteberry Extract, L-tryptophan, St. John's wort"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1635160165/staging/products/pms-gummies/PRODUCT%20IMAGES/PMS%20Gummies_1000x750.png",
        title:"PMS Gummies",
        price:999,
        for:"FOR Managing PMS Symptoms",
        with:"WITH Chasteberry Extract, L-tryptophan, St. John's wort"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1635160165/staging/products/pms-gummies/PRODUCT%20IMAGES/PMS%20Gummies_1000x750.png",
        title:"PMS Gummies",
        price:999,
        for:"FOR Managing PMS Symptoms",
        with:"WITH Chasteberry Extract, L-tryptophan, St. John's wort"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1635160165/staging/products/pms-gummies/PRODUCT%20IMAGES/PMS%20Gummies_1000x750.png",
        title:"PMS Gummies",
        price:999,
        for:"FOR Managing PMS Symptoms",
        with:"WITH Chasteberry Extract, L-tryptophan, St. John's wort"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1635160165/staging/products/pms-gummies/PRODUCT%20IMAGES/PMS%20Gummies_1000x750.png",
        title:"PMS Gummies",
        price:999,
        for:"FOR Managing PMS Symptoms",
        with:"WITH Chasteberry Extract, L-tryptophan, St. John's wort"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1635160165/staging/products/pms-gummies/PRODUCT%20IMAGES/PMS%20Gummies_1000x750.png",
        title:"PMS Gummies",
        price:999,
        for:"FOR Managing PMS Symptoms",
        with:"WITH Chasteberry Extract, L-tryptophan, St. John's wort"
    },
]

var feminineArr = [
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1624343637/staging/products/Intimate%20Wash/New%20Carousel/1600x1200.jpg",
        title:"pH Balancing Intimate Wash",
        price:400,
        for:"FOR Maintaining ph balance & hygiene",
        with:"WITH 1% Niacinamide, Lactic Acid, Tea Tree"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1624343637/staging/products/Intimate%20Wash/New%20Carousel/1600x1200.jpg",
        title:"pH Balancing Intimate Wash",
        price:400,
        for:"FOR Maintaining ph balance & hygiene",
        with:"WITH 1% Niacinamide, Lactic Acid, Tea Tree"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1624343637/staging/products/Intimate%20Wash/New%20Carousel/1600x1200.jpg",
        title:"pH Balancing Intimate Wash",
        price:400,
        for:"FOR Maintaining ph balance & hygiene",
        with:"WITH 1% Niacinamide, Lactic Acid, Tea Tree"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1624343637/staging/products/Intimate%20Wash/New%20Carousel/1600x1200.jpg",
        title:"pH Balancing Intimate Wash",
        price:400,
        for:"FOR Maintaining ph balance & hygiene",
        with:"WITH 1% Niacinamide, Lactic Acid, Tea Tree"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1624343637/staging/products/Intimate%20Wash/New%20Carousel/1600x1200.jpg",
        title:"pH Balancing Intimate Wash",
        price:400,
        for:"FOR Maintaining ph balance & hygiene",
        with:"WITH 1% Niacinamide, Lactic Acid, Tea Tree"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1624343637/staging/products/Intimate%20Wash/New%20Carousel/1600x1200.jpg",
        title:"pH Balancing Intimate Wash",
        price:400,
        for:"FOR Maintaining ph balance & hygiene",
        with:"WITH 1% Niacinamide, Lactic Acid, Tea Tree"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1624343637/staging/products/Intimate%20Wash/New%20Carousel/1600x1200.jpg",
        title:"pH Balancing Intimate Wash",
        price:400,
        for:"FOR Maintaining ph balance & hygiene",
        with:"WITH 1% Niacinamide, Lactic Acid, Tea Tree"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1624343637/staging/products/Intimate%20Wash/New%20Carousel/1600x1200.jpg",
        title:"pH Balancing Intimate Wash",
        price:400,
        for:"FOR Maintaining ph balance & hygiene",
        with:"WITH 1% Niacinamide, Lactic Acid, Tea Tree"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1624343637/staging/products/Intimate%20Wash/New%20Carousel/1600x1200.jpg",
        title:"pH Balancing Intimate Wash",
        price:400,
        for:"FOR Maintaining ph balance & hygiene",
        with:"WITH 1% Niacinamide, Lactic Acid, Tea Tree"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1624343637/staging/products/Intimate%20Wash/New%20Carousel/1600x1200.jpg",
        title:"pH Balancing Intimate Wash",
        price:400,
        for:"FOR Maintaining ph balance & hygiene",
        with:"WITH 1% Niacinamide, Lactic Acid, Tea Tree"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1624343637/staging/products/Intimate%20Wash/New%20Carousel/1600x1200.jpg",
        title:"pH Balancing Intimate Wash",
        price:400,
        for:"FOR Maintaining ph balance & hygiene",
        with:"WITH 1% Niacinamide, Lactic Acid, Tea Tree"
    },
    {
        image:"https://res.cloudinary.com/mosaic-wellness/image/upload/f_auto,w_800,c_limit/v1624343637/staging/products/Intimate%20Wash/New%20Carousel/1600x1200.jpg",
        title:"pH Balancing Intimate Wash",
        price:400,
        for:"FOR Maintaining ph balance & hygiene",
        with:"WITH 1% Niacinamide, Lactic Acid, Tea Tree"
    },
    
]

localStorage.setItem("skinData",JSON.stringify(skinArr));
localStorage.setItem("hairData",JSON.stringify(hairArr));
localStorage.setItem("weightData",JSON.stringify(weightArr));
localStorage.setItem("pcosData",JSON.stringify(pcosArr));
localStorage.setItem("feminineData",JSON.stringify(feminineArr));



