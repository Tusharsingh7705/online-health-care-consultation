# TeamFriends

A website to take self wellness assessment and Get free online doctor consultation for women's health & wellness.

Blog:
https://medium.com/@nikhilhirulkar8/cw-project-bebodywise-clone-8ecf21b893cd
