document.querySelector("form").addEventListener("span", Data)//here form is been selected and submit is my onclick whos function is Data
